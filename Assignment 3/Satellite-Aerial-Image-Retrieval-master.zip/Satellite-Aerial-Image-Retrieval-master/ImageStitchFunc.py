import matplotlib.pyplot as plt
import numpy as np
import os

baseline_Dimension = 256
def startStitch(tup, folder):
    height, weight = np.shape(tup)
    findShape = np.zeros((height * baseline_Dimension, weight * baseline_Dimension, 3), np.uint8)

    for i in range(len(tup)):
        heightShape = np.zeros((1 * baseline_Dimension, weight * baseline_Dimension, 3), np.uint8)
        for j in tup[i]:
            img = plt.imread(folder + j + '.jpg')
            heightShape = np.hstack((heightShape, img))

        heightShape = heightShape[:, weight * baseline_Dimension:, :3]
        findShape = np.vstack((findShape, heightShape))
    findShape = findShape[height * baseline_Dimension:, :, :3]
    path = os.path.split(os.path.abspath(folder))[0]
    plt.imsave(path + '/outputImage.jpg', findShape)
    return findShape
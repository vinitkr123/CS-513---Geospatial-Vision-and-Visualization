"""
Created on Tue Apr 2,2019
AerialImageRetrieval.py
"""

import urllib
import os
import sys
import shutil
import matplotlib.pyplot as plt
import numpy as np
import HelperFunc
import ImageStitchFunc



# Global parameters
bing_api = 'Alz_8myhduuWvB6LkaEtFJUEzgvRFAsBk5294VS5Hpzgmk8fhodtojUE6b2dpXqm'
path = 'D:/Masters/GEO\Assignment 3/Satellite-Aerial-Image-Retrieval-master'
temp_path = path+'/temp/'

#Creates forlder to store tiled images
shutil.rmtree(temp_path, ignore_errors=True)
os.mkdir(temp_path, 0o777)
print("Temp folder created")


# Download desired image from web server
def downloadImage(quadrantKey, name):
    img = os.path.join(temp_path, name)
    url = 'http://h0.ortho.tiles.virtualearth.net/tiles/h' + quadrantKey + '.jpeg?g=131&key=' + bing_api
    try:
        page = urllib.urlretrieve(url, img)
    except Exception as e:
        return 0, e
    # urllib.urlretrieve(url, img)
    print("Image Download Complete...")
    return 1, 'success'


def displayImage(name):
    print("Displaying Image...")
    img = os.path.join(temp_path, name)
    ob = plt.imread(img)
    plt.imshow(ob)
    plt.show()


def loadNullImage():
    img = os.path.join(path, 'null.jpg')
    nullObj = plt.imread(img)
    return nullObj



# This function will get neighbouring tiles,
# download them in a folder, renaming using hash function,
# and display them
def getBoundingTileImages(tx1, ty1, tx2, ty2, LoD):
    tup = []
    for y in range(ty1, ty2 + 1):
        col = []
        for x in range(tx1, tx2 + 1):
            print ("\nBounding tiles: %s, %s " % (x, y))
            quadKey = HelperFunc.tileXYToQuadKey(x, y, LoD)
            # Hash the file name for convenience in stitching
            name = str(x % tx1) + str(y % ty1) + '.jpg';
            print(name)
            val, msg = downloadImage(quadKey, name)

            if val == 0:
                print("Not able to download the image...")
                print(msg)
                return tup, 1

            # Check if the image has been downloaded properly
            if np.all((plt.imread(os.path.join(temp_path, name))) == loadNullImage()) == True:
                print("Could not download Image...")
                print("Either a connection problem or image doesn't exist at level...")
                return tup, 1
            # displayImage(name)
            col.append(str(x % tx1) + str(y % ty1))
        tup.append(col)
    print(tup)
    return tup, 0


def validateCoordinates(latitude1, longititude1, latitude2, longitude2, maximumLoad):
    for i in range(maximumLoad, 0, -1):
        tiles_x1, tiles_y1 = HelperFunc.latLongToTiles(latitude1, longititude1, i)
        tiles_x2, tiles_y2 = HelperFunc.latLongToTiles(latitude2, longitude2, i)

        if tiles_y1 > tiles_y2:
            tiles_y1, tiles_y2 = tiles_y2, tiles_y1

        if tiles_x1 > tiles_x2:
            tiles_x1, tiles_x2 = tiles_x2, tiles_x1

        if (tiles_x2 - tiles_x1 >= 1) and (tiles_y2 - tiles_y1 >= 1):
            print ("Best detail found at Level: %s" % (i))
            print ("Transformed Tiles: %s, %s, %s, %s " % (tiles_x1, tiles_y1, tiles_x2, tiles_y2))
            return tiles_x1, tiles_y1, tiles_x2, tiles_y2, i

    print ("Program Interruption: Coordinates are on the same tiles...No image will be downloaded\n")
    sys.exit()


def main(latitude1, longititude1, latitude2, longitude2):
    maximumLoad = 23
    found = 1
    while (found == 1):
        tx1, ty1, tx2, ty2, LoD = validateCoordinates(latitude1, longititude1, latitude2, longitude2, maximumLoad)
        tup, found = getBoundingTileImages(tx1, ty1, tx2, ty2, LoD)
        maximumLoad = maximumLoad - 1
        if maximumLoad < 0:
            break

            # Stitch from directory
    fs = ImageStitchFunc.startStitch(tup, temp_path)
    print("Bounding of images is complete. Displaying image...")
    plt.imshow(fs)
    plt.show()

#main(48.859261, 2.293380, 48.856953, 2.296294) #Effiel Tower
#main(41.839128, -87.628503, 41.838744, -87.626847)  # IIT Stuart Building Coordinates
#main(41.882981, -87.623496, 41.882397, -87.623076)	# Chicago Bean
main(41.892026, -87.608168, 41.891387, -87.606156)  # Chicago Navy Pier
#main(40.690135, -74.045679, 40.688524, -74.043366)  # Statue of Liberty, NY

